package hotel.room.reservation.system.dao;

public class RoomDoa {
	

}
