package hotel.room.reservation.system.service;

import hotel.room.reservation.system.exception.CustomException;

public class RoomService {
	private boolean s=true;

		
	public boolean isS() {
		return s;
	}


	public void setS(boolean s) {
		this.s = s;
	}


	public void isRoomAvaiable() throws CustomException {
		if(s==false) {
			throw new CustomException("room is not available");
		}		
	}
	

}
