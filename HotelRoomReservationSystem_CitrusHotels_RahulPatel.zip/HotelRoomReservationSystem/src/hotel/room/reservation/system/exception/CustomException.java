package hotel.room.reservation.system.exception;

public class CustomException extends Exception {
	public CustomException(String Str) {
		super(Str);
	}
	
}
